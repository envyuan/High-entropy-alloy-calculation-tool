package HEAcalculate;

/**
 * @author YEW-Lenovo
 * @Description
 * @date 2022/2/14
 */
public class HeaException extends Exception{
    static final long serialVersionUID = -33875229948L;

    public HeaException(){}

    public HeaException(String message){
        super(message);
    }
}
